const mongoose = require("mongoose");

async function connectDB() {
  try {
    mongoose.set("strictQuery", true);
    const conn = await mongoose.connect(process.env.MONGODB_URI);
    console.log(`[rumion] MongoDB connected: ${conn.connection.host}`);
  } catch (err) {
    console.error(`[rumion] MongoDB connection failed: ${err.message}`);
    process.exit(1);
  }
}

module.exports = connectDB;
